#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Adding Motion Forge marketplace from: $ROOT"
codex plugin marketplace remove motion-forge-local >/dev/null 2>&1 || true
codex plugin marketplace add "$ROOT"

echo "Installing motion-forge@motion-forge-local"
codex plugin add motion-forge@motion-forge-local

echo "Motion Forge installed."
