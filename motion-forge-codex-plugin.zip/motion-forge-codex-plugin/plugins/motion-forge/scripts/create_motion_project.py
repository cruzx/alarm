#!/usr/bin/env python3
"""Create a Motion Forge Three.js animation project."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    return slug or "motion-forge-project"


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def template_file(name: str) -> str:
    template_path = Path(__file__).resolve().parents[1] / "assets" / "templates" / name
    return template_path.read_text(encoding="utf-8")


def package_json(name: str) -> str:
    data = {
        "name": name,
        "version": "0.1.0",
        "private": True,
        "type": "module",
        "scripts": {
            "dev": "vite --host 127.0.0.1",
            "build": "vite build",
            "preview": "vite preview --host 127.0.0.1",
            "export:mp4": "node tools/export-mp4.mjs",
            "export:lottie": "node tools/export-lottie.mjs",
        },
        "dependencies": {
            "three": "^0.185.1",
            "vite": "^8.1.4",
        },
        "devDependencies": {
            "playwright": "^1.61.1",
        },
    }
    return json.dumps(data, indent=2) + "\n"


def index_html(title: str) -> str:
    return f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{title}</title>
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%23111216'/%3E%3Cpath d='M14 42h8l4-20 6 20h6l6-20 4 20h8L50 14H39l-4 16-4-16H20L14 42z' fill='%233f82ff'/%3E%3C/svg%3E" />
  </head>
  <body>
    <canvas id="stage" aria-label="Motion Forge composition preview"></canvas>
    <script type="module" src="/src/main.js"></script>
  </body>
</html>
"""


def main_js(width: int, height: int, duration: float, fps: int) -> str:
    return (
        template_file("main.js")
        .replace("__WIDTH__", str(width))
        .replace("__HEIGHT__", str(height))
        .replace("__DURATION__", f"{duration:.3f}")
        .replace("__FPS__", str(fps))
    )


def lottie_spec(width: int, height: int, duration: float, fps: int) -> str:
    total_frames = round(duration * fps)
    return f"""export function buildLottie() {{
  const width = {width};
  const height = {height};
  const fps = {fps};
  const totalFrames = {total_frames};
  const cx = width / 2;
  const cy = height / 2;

  const circleShape = (color, radius) => ({{
    ty: "gr",
    nm: "circle",
    it: [
      {{
        ty: "el",
        nm: "ellipse",
        p: {{ a: 0, k: [0, 0] }},
        s: {{ a: 0, k: [radius * 2, radius * 2] }},
      }},
      {{
        ty: "fl",
        nm: "fill",
        c: {{ a: 0, k: color }},
        o: {{ a: 0, k: 100 }},
        r: 1,
      }},
      {{
        ty: "tr",
        p: {{ a: 0, k: [0, 0] }},
        a: {{ a: 0, k: [0, 0] }},
        s: {{ a: 0, k: [100, 100] }},
        r: {{ a: 0, k: 0 }},
        o: {{ a: 0, k: 100 }},
      }},
    ],
  }});

  const animatedPosition = (offset, radius) => ({{
    a: 1,
    k: [
      {{ t: 0, s: [cx + radius, cy + offset, 0], e: [cx, cy - radius + offset, 0], i: {{ x: [0.65], y: [1] }}, o: {{ x: [0.35], y: [0] }} }},
      {{ t: totalFrames / 2, s: [cx, cy - radius + offset, 0], e: [cx + radius, cy + offset, 0], i: {{ x: [0.65], y: [1] }}, o: {{ x: [0.35], y: [0] }} }},
      {{ t: totalFrames, s: [cx + radius, cy + offset, 0] }},
    ],
  }});

  return {{
    v: "5.12.2",
    fr: fps,
    ip: 0,
    op: totalFrames,
    w: width,
    h: height,
    nm: "Motion Forge Lottie Companion",
    ddd: 0,
    assets: [],
    layers: [
      {{
        ddd: 0,
        ind: 1,
        ty: 4,
        nm: "Core pulse",
        sr: 1,
        ks: {{
          o: {{ a: 0, k: 100 }},
          r: {{ a: 1, k: [{{ t: 0, s: [0], e: [360] }}, {{ t: totalFrames, s: [360] }}] }},
          p: {{ a: 0, k: [cx, cy, 0] }},
          a: {{ a: 0, k: [0, 0, 0] }},
          s: {{ a: 1, k: [{{ t: 0, s: [86, 86, 100], e: [108, 108, 100] }}, {{ t: totalFrames / 2, s: [108, 108, 100], e: [86, 86, 100] }}, {{ t: totalFrames, s: [86, 86, 100] }}] }},
        }},
        shapes: [circleShape([0.1059, 0.498, 0.4196, 1], Math.min(width, height) * 0.12)],
        ip: 0,
        op: totalFrames,
        st: 0,
        bm: 0,
      }},
      ...[0, 1, 2].map((index) => ({{
        ddd: 0,
        ind: index + 2,
        ty: 4,
        nm: `Orbit accent ${{index + 1}}`,
        sr: 1,
        ks: {{
          o: {{ a: 0, k: 100 }},
          r: {{ a: 1, k: [{{ t: 0, s: [index * 120], e: [index * 120 + 360] }}, {{ t: totalFrames, s: [index * 120 + 360] }}] }},
          p: animatedPosition((index - 1) * height * 0.045, Math.min(width, height) * (0.21 + index * 0.03)),
          a: {{ a: 0, k: [0, 0, 0] }},
          s: {{ a: 0, k: [100, 100, 100] }},
        }},
        shapes: [circleShape(index === 1 ? [0.949, 0.7216, 0.2941, 1] : [0.1255, 0.1412, 0.1647, 1], Math.min(width, height) * 0.028)],
        ip: 0,
        op: totalFrames,
        st: 0,
        bm: 0,
      }})),
    ],
  }};
}}
"""


def export_lottie() -> str:
    return """import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { buildLottie } from "../src/lottie-spec.js";

const outDir = path.resolve("exports");
await mkdir(outDir, { recursive: true });
await writeFile(path.join(outDir, "motion.json"), JSON.stringify(buildLottie(), null, 2));
console.log("Wrote exports/motion.json");
"""


def export_mp4() -> str:
    return """import { mkdir, readFile, rm } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { chromium } from "playwright";

const port = Number(process.env.MOTION_FORGE_PORT || 4173);
const baseUrl = `http://127.0.0.1:${port}`;
const frameDir = path.resolve("exports", "frames");
const outFile = path.resolve("exports", "motion.mp4");
const projectJsonPath = process.env.MOTION_FORGE_PROJECT_JSON;

function run(command, args, options = {}) {
  return spawn(command, args, { stdio: "inherit", shell: false, ...options });
}

async function waitForServer() {
  const deadline = Date.now() + 20000;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(baseUrl);
      if (res.ok) return;
    } catch {
      await new Promise((resolve) => setTimeout(resolve, 300));
    }
  }
  throw new Error(`Vite did not start at ${baseUrl}`);
}

if (spawnSync("ffmpeg", ["-version"], { stdio: "ignore" }).status !== 0) {
  throw new Error("ffmpeg is required for MP4 export. Install it, then rerun npm run export:mp4.");
}

await rm(frameDir, { recursive: true, force: true });
await mkdir(frameDir, { recursive: true });

const server = run("npx", ["vite", "--host", "127.0.0.1", "--port", String(port)]);

try {
  await waitForServer();
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1080, height: 1080 }, deviceScaleFactor: 1 });
  if (projectJsonPath) {
    const projectJson = JSON.parse(await readFile(path.resolve(projectJsonPath), "utf8"));
    await page.addInitScript((project) => {
      window.__MOTION_FORGE_PROJECT__ = project;
    }, projectJson);
  }
  await page.goto(`${baseUrl}/?capture=1`, { waitUntil: "networkidle" });

  const meta = await page.evaluate(() => ({
    duration: window.motionForge.duration,
    fps: window.motionForge.fps,
    width: window.motionForge.width,
    height: window.motionForge.height,
  }));
  await page.setViewportSize({ width: meta.width, height: meta.height });

  const frames = Math.round(meta.duration * meta.fps);
  const captureTarget = (await page.locator("#capture-frame").count()) > 0 ? page.locator("#capture-frame") : page.locator("#stage");
  for (let i = 0; i < frames; i += 1) {
    await page.evaluate((seconds) => window.motionForge.seek(seconds), i / meta.fps);
    await captureTarget.screenshot({ path: path.join(frameDir, `frame-${String(i).padStart(5, "0")}.png`) });
  }
  await browser.close();

  const encode = spawnSync(
    "ffmpeg",
    [
      "-y",
      "-framerate",
      String(meta.fps),
      "-i",
      path.join(frameDir, "frame-%05d.png"),
      "-pix_fmt",
      "yuv420p",
      "-vf",
      `scale=${meta.width}:${meta.height}:force_original_aspect_ratio=decrease,pad=${meta.width}:${meta.height}:(ow-iw)/2:(oh-ih)/2`,
      outFile,
    ],
    { stdio: "inherit" },
  );
  if (encode.status !== 0 || !existsSync(outFile)) {
    throw new Error("ffmpeg failed to create exports/motion.mp4");
  }
  console.log("Wrote exports/motion.mp4");
} finally {
  server.kill("SIGTERM");
}
"""


def readme(name: str, width: int, height: int, duration: float, fps: int) -> str:
    return f"""# {name}

Generated by Motion Forge.

## Preview

```bash
npm install
npm run dev
```

## Export

```bash
npm run export:mp4
npm run export:lottie
```

- MP4 renders the real Three.js scene by capturing deterministic canvas frames.
- Lottie writes `exports/motion.json` from `src/lottie-spec.js`.
- Real Three.js depth, lights, shaders, and camera motion do not convert losslessly to Lottie. Keep `src/lottie-spec.js` as the vector-safe companion when Lottie fidelity matters.

## Defaults

- Size: {width} x {height}
- Duration: {duration:g}s
- FPS: {fps}
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a Motion Forge project.")
    parser.add_argument("name", help="Project name")
    parser.add_argument("--path", default=".", help="Parent directory for the generated project")
    parser.add_argument("--width", type=int, default=1080)
    parser.add_argument("--height", type=int, default=1080)
    parser.add_argument("--duration", type=float, default=5.0)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--force", action="store_true", help="Overwrite an existing project directory")
    args = parser.parse_args()

    project_name = slugify(args.name)
    root = Path(args.path).expanduser().resolve() / project_name
    if root.exists() and not args.force:
        raise SystemExit(f"{root} already exists. Use --force to overwrite generated files.")

    write(root / "package.json", package_json(project_name))
    write(root / "index.html", index_html(project_name))
    write(root / "src" / "main.js", main_js(args.width, args.height, args.duration, args.fps))
    write(root / "src" / "motion-editor.js", template_file("motion-editor.js"))
    write(root / "src" / "styles.css", template_file("styles.css"))
    write(root / "src" / "lottie-spec.js", lottie_spec(args.width, args.height, args.duration, args.fps))
    write(root / "tools" / "export-lottie.mjs", export_lottie())
    write(root / "tools" / "export-mp4.mjs", export_mp4())
    write(root / "README.md", readme(project_name, args.width, args.height, args.duration, args.fps))
    write(root / ".gitignore", "node_modules\ndist\nexports\n.DS_Store\n")

    print(f"Created Motion Forge project: {root}")
    print("Next: npm install && npm run dev")


if __name__ == "__main__":
    main()
