# Motion Forge Handoff

## Current State

- Local plugin source: `/Users/xiangchengjin/plugins/motion-forge`
- Marketplace file: `/Users/xiangchengjin/.agents/plugins/marketplace.json`
- Installed plugin cache: `/Users/xiangchengjin/.codex/plugins/cache/personal/motion-forge/0.1.0+codex.20260710111119`
- Codex marketplace install command used: `codex plugin add motion-forge@personal`

## What Works

- Plugin manifest validates.
- Plugin provides the `motion-forge` skill.
- Generator script creates a Vite + Three.js motion project with an AE-style editor shell.
- Editor visual style now follows a modern dark video editor with a focused Project Tools panel, center preview, AI/inspector panel, and multi-track timeline.
- Removed non-working decorative navigation/search/tool-tab rows from the editor so the visible UI only keeps controls that belong to the current motion workflow.
- Generated projects open paused at 0s as a blank prompt-first workspace. The 3D coin scene is created only after a brief such as `3D rotating gold coin`.
- Generated project supports deterministic frame seeking through `window.motionForge.seek(seconds)`.
- Generated project includes layers, inspector controls, visible diamond keyframe points, scrubber playback, layer delete/group/order controls, and drag-to-reorder layers.
- Generated project includes Figma URL/token import with support for ordinary Figma links and MCP-style links that expose a file key/node id. Positioned Figma nodes become independent layers with Position X/Y, Scale, Rotation, and Opacity tracks.
- Nested Figma frames/groups are expanded into visible child layers while preserving painted containers, so imported pages show inner content instead of only outer boxes.
- Figma URL import remembers the token in browser local storage and exposes a `Forget` button; project JSON export still excludes the token.
- Imported Figma homepage/page layers are fetched first, then `Animate Selected` only applies Position, Scale, Rotation, and Opacity keyframes to checked motion-target layers. Large canvas/background layers are marked static by default.
- Center canvas layers are clickable and stay in sync with the left layer list, inspector, timeline selection, and selected-layer outline.
- Imported previews clip Figma layers to the selected Figma frame bounds and render a full Figma frame snapshot as the visual source of truth. Child layers remain selectable/animatable as transparent hit areas by default, which keeps the imported design faithful before motion is applied.
- Figma import now preserves the original Figma tree grouping instead of flattening every node into one level. Imported layers carry `parentId`, `depth`, `groupPath`, and child counts, and the left layer list renders Figma groups/frames as indented parent rows.
- Figma parent rows now support expand/collapse controls. Collapsing a parent hides descendants in both the layer list and timeline while keeping the design preview intact; if a hidden child was selected, selection moves to the collapsed parent.
- The imported Figma snapshot layer now behaves as the root Frame parent, so top-level Figma children are indented under the current frame instead of appearing as separate root rows. The left layer list has its own vertical scrolling region so deep Figma trees remain reachable.
- Removed the left-side Selected Layer Motion preset panel. The layer list now extends to the bottom of the project panel and remains the only scrollable region there.
- Canvas elements can be dragged directly in the composition preview. Holding Shift while dragging constrains movement to horizontal or vertical. Holding Shift while using the mouse wheel zooms the canvas between 20% and 500%, and the composition area scrolls when the zoomed canvas is larger than the viewport.
- The top prompt bar is now the AI motion prompt input. It shows the active selected layer(s) as blue target chips and writes real Position/Scale/Rotation/Opacity keyframes to the selected layer first. The inspector includes selectable motion engines: Three.js, p5.js, Lottie, and CSS Motion; the selected engine changes the local keyframe generation style.
- Selecting a layer focuses only the internal timeline track area, not the whole page.
- Layer keyboard shortcuts include Delete/Backspace to delete the selected layer and Command/Control+G to group checked motion-target layers.
- Undo/redo is supported for project edits: Command/Control+Z restores the previous project snapshot, and Command/Control+Shift+Z or Command/Control+Y redoes it. Covered operations include Figma import, layer delete/reorder/group/ungroup, target checkbox changes, canvas size changes, generated motion, applied presets, keyframes, and property slider edits.
- The lower-left refine panel prompts for checked target layers instead of creating blank drafts.
- Playback controls live above the timeline as centered SVG icon buttons for first frame, previous frame, play/pause, next frame, and last frame. Canvas size, zoom, quality, project download, and project JSON controls are wired to real actions or explicit status feedback.
- Timeline ruler, playhead, keyframes, and the bottom scrubber now share the same time-region origin, so dragging/scrubbing starts from the first frame instead of the far-left label area.
- `npm run build` passes on the generated smoke project.
- `npm run export:lottie` writes `exports/motion.json`.
- `npm run export:mp4` captures canvas frames and writes `exports/motion.mp4` with ffmpeg.

## Tested Smoke Project

- Temporary path: `/tmp/motion-forge-smoke-new.9W2zBE/smoke-demo`
- Test settings: 320 x 320, 1 second, 6 fps
- npm install result: 0 vulnerabilities
- Build note: Vite warns that the Three.js bundle is larger than 500 KB. This is expected for a starter Three.js scene.

## Product Boundary

- MP4 is the faithful export path for true Three.js 3D.
- Lottie should be treated as a vector-safe companion animation or simplified 2.5D version.
- Lossless Three.js-to-Lottie conversion is not promised.

## Best Next Step

Continue the authoring surface:

- curve editor
- draggable keyframes
- nested/precomp timelines
- masks and shape layers
- direct Figma URL/API token import
- real model/material import
- camera/path editor
- material and lighting presets
- deeper AI prompt-to-scene rewriting through Codex
