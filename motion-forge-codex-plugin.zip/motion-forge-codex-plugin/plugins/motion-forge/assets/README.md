# Assets

Optional plugin card icons, screenshots, and future templates can live here.
