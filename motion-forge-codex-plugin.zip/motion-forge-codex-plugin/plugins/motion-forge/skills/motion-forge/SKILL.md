---
name: motion-forge
description: Generate AI-assisted Three.js animation workspaces with timeline editing, Figma JSON import, layer splitting, and export-ready motion assets. Use when the user asks for 3D motion, Three.js motion, product/UI animation, loading animation, logo animation, Figma-to-motion, Figma import, Lottie export, MP4 export, keyframes, timeline controls, After Effects-style motion design, or a Codex workflow for making motion design.
---

# Motion Forge

Motion Forge turns motion briefs into local, runnable animation projects. Prefer creating a project the user can edit, preview, and export instead of only describing animation ideas.

## Product Direction

Treat Motion Forge as an AI-assisted, lightweight After Effects for Three.js motion:

- composition preview in the center
- video-editor-style dark workspace with left app rail, project tools, center preview, right AI/inspector panel, and bottom multi-track timeline
- layer list on the left
- Figma URL/token import and Figma JSON import that turn positioned Figma nodes into separate animatable layers
- homepage/product-page motion preset that writes staggered Position, Scale, Rotation, and Opacity keyframes for imported Figma layers
- explicit motion-target selection so presets only modify chosen layers, not the full imported canvas
- inspector controls on the right
- timeline, time ruler, scrubber, tracks, and keyframes along the bottom
- selected-layer motion actions for refining checked motion-target layers only
- a prominent motion brief input that creates the starting scene; default projects should open blank instead of auto-playing a baked-in demo
- deterministic preview and export clock

Do not claim full After Effects parity. The current target is the core motion workflow: imported layers, properties, keyframes, preview, and export.

## Default Workflow

1. Convert the user's brief into a compact motion spec:
   - format: `mp4`, `lottie`, or `both`
   - canvas size, duration, fps, visual style, camera behavior, looping behavior
   - whether the Lottie output must be vector-safe
   - whether the user is starting from a Figma URL, token, JSON export, or API response
2. If no destination is given, create the project in the current working directory.
3. Use the generator script when starting a fresh project:

```bash
python3 ~/plugins/motion-forge/scripts/create_motion_project.py <project-name> \
  --duration 5 \
  --fps 30 \
  --width 1080 \
  --height 1080
```

4. Edit the generated `src/main.js` for true Three.js motion, `src/motion-editor.js` for the authoring surface and Figma-node layer handling, and `src/lottie-spec.js` for the Lottie-compatible companion animation.
5. Run `npm install`, then verify with `npm run build`.
6. For MP4 output, run `npm run export:mp4`. This requires `ffmpeg` and Playwright browser dependencies.
7. For Lottie output, run `npm run export:lottie`.

## Export Rules

- MP4 is the source-of-truth export for real Three.js 3D, lighting, particles, depth, post-processing, or camera moves.
- Lottie is only fully faithful for vector-safe 2D/2.5D shape motion. When the brief asks for real 3D plus Lottie, create a simplified Lottie companion rather than claiming lossless conversion.
- If the user needs both formats, keep the visual language aligned: same timing, palette, easing, and composition, with 3D detail reserved for MP4.
- Prefer deterministic animation based on an explicit time value. Generated projects expose `window.motionForge.seek(seconds)` so the exporter can capture exact frames.

## Quality Bar

- Make the first screen the animation preview, not a landing page.
- Start from a blank prompt-first workspace. Do not auto-show a coin or other demo unless the user brief asks for it.
- Keep the editor dense and tool-like: no marketing hero, no decorative app cards.
- Prefer a polished video-editor layout: dark chrome, left rail navigation, Project Tools panel, prominent Preview/Share/Render actions, center media preview, right AI panel, and multi-track timeline.
- The timeline must support scrubbing, play/pause, visible keyframes, layer tracks, and property editing.
- Figma import should preserve node names and create independent Position X/Y, Scale, Rotation, and Opacity tracks for every imported renderable node.
- For nested Figma frames/groups, expand visible inner nodes and preserve painted containers so the preview shows real page content rather than only outer frame boxes.
- For homepage/page-design imports, preserve the current Figma canvas as the visual reference. Do not animate large full-canvas/background layers by default; require selected motion targets before applying preset keyframes.
- Figma URL import uses `GET https://api.figma.com/v1/files/:key` with `X-Figma-Token`. The editor may remember the token in browser local storage for convenience, but the token must not be saved into generated project JSON or exported motion assets.
- AI features should apply structured drafts to the project and be honest about what is local/preset-based versus what Codex can rewrite in code.
- Do not create blank scenes when imported layers exist; selected-layer motion actions should require checked motion-target layers and modify only those layers.
- Use stable dimensions and avoid layout shifts around the canvas.
- Keep loops seamless when the user asks for a loader or ambient motion.
- Before finishing, verify at least `npm run build`. If MP4 or Lottie export is requested, run the relevant export command too.
- Mention any export limitation plainly, especially for Lottie and real 3D.

## Project Shape

Generated projects include:

- `src/main.js`: Three.js scene, deterministic clock, keyframe runtime.
- `src/motion-editor.js`: AE-style local editor shell.
- Figma import supports pasted Figma URLs plus a token with `file_content:read`, or JSON shaped like a Figma REST API file/node response or a plugin-exported document tree. The token field is restored from browser local storage when present and can be cleared from the UI. Do not promise direct `.fig` binary parsing.
- `src/styles.css`: professional dark tool UI.
- `src/lottie-spec.js`: vector-safe Lottie companion animation.
- `tools/export-mp4.mjs`: browser frame capture plus ffmpeg MP4 encoding.
- `tools/export-lottie.mjs`: writes a Lottie JSON file.
- `README.md`: local usage and export notes.
