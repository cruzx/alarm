# Motion Forge

Motion Forge is a local Codex plugin for creating AI-assisted, export-ready motion projects.

It gives Codex one focused workflow:

- generate a runnable Three.js animation project
- open as a blank, prompt-first motion workspace instead of a baked-in demo scene
- provide a video-editor-style dark workspace with project tools, center preview, inspector panel, and multi-track timeline controls
- import Figma JSON and split positioned nodes into separate animatable layers
- apply a homepage motion preset to imported Figma layers with staggered entrance keyframes
- select explicit imported layers as motion targets before applying a preset
- apply structured homepage motion presets to selected motion-target layers
- keep animation deterministic for frame capture
- export real 3D motion to MP4
- export a Lottie-compatible companion animation when vector fidelity is possible

## Generate a Project

```bash
python3 ~/plugins/motion-forge/scripts/create_motion_project.py kinetic-logo --duration 5 --fps 30 --width 1080 --height 1080
```

Then:

```bash
cd kinetic-logo
npm install
npm run dev
```

## Export

```bash
npm run export:mp4
npm run export:lottie
```

MP4 export requires `ffmpeg`. Lottie export writes `exports/motion.json`.

## Important Lottie Note

Three.js and Lottie are different rendering models. Real 3D lighting, shaders, particles, and camera depth should be exported as MP4. Lottie should be treated as a vector-safe companion animation or a constrained 2.5D version of the same motion language.

## Figma Import

Use the editor's Figma URL importer with a token that has `file_content:read`, or import JSON shaped like a Figma REST API response/plugin-exported document tree. Imported nodes become independent layers with Position X/Y, Scale, Rotation, and Opacity tracks. Nested Figma frames and groups are expanded into visible child layers so inner text, cards, and buttons can show and animate instead of only displaying outer boxes. Tokens are used in the browser request and are not written into the project.

The editor remembers the Figma token in the browser's local storage after entry, so the user does not need to paste it on every session. The token can be cleared with the importer `Forget` button.

For homepage or product-page imports, fetch layers first, select the exact layers that should move, then use the selected-layer motion action to generate a structured entrance timeline. Large canvas/background layers are treated as static references by default.
