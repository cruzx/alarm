# Motion Forge Codex Plugin

Motion Forge is a Codex plugin for generating AI-assisted Three.js motion workspaces with Figma import, grouped layers, timeline keyframes, undo/redo, MP4 export, and Lottie companion export.

## Install

After downloading and unzipping this folder:

```bash
cd motion-forge-codex-plugin
./install.sh
```

This registers the local marketplace and installs:

```bash
motion-forge@motion-forge-local
```

## Use

In Codex, mention:

```text
@motion-forge
```

Example:

```text
@motion-forge 给这个 Figma 页面做首页进入动效
```

## What Is Included

- `.agents/plugins/marketplace.json`: local Codex marketplace entry
- `plugins/motion-forge`: the plugin source
- `plugins/motion-forge/skills/motion-forge/SKILL.md`: Codex workflow skill
- `plugins/motion-forge/scripts/create_motion_project.py`: project generator
- `plugins/motion-forge/assets/templates`: generated editor templates
